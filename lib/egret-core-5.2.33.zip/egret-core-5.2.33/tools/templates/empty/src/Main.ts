class Main extends egret.DisplayObjectContainer {

    public constructor() {
        super();
    }
}