export declare function minify(files:any,option?:any):any;

//source-map的功能被精简掉了，其他功能正常。