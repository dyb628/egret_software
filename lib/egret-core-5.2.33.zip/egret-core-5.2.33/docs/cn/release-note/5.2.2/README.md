# 白鹭引擎 5.2.2 发布日志


---


白鹭引擎在 2018年5月25日 正式发布了 5.2 稳定版本。在 2018年6月8日，我们将发布 5.2.2 稳定版本。本次版本是 5.2 版本的一次集中性缺陷修复以及添加```Egretia SDK```



## 2D 渲染 - JavaScript 

* 新增内置库 [Egretia SDK](https://github.com/Egretia/egretia-docs/tree/master/cn)，嵌入 Web 钱包，游戏调试可以直接使用 Web 钱包进⾏调试
* 修复开启C++显示列表情况下，龙骨动画颜色变换功能失效问题

## AssetsManager

* 修复```RES.config.addResourceData```添加相同资源导致异常问题

## 命令行

* 修复版本升级判断异常问题