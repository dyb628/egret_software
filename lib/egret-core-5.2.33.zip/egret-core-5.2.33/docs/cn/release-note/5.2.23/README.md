# 白鹭引擎 5.2.23 发布日志
白鹭引擎在 2019年7月9日，发布 5.2.23 稳定版本。

## 2D 渲染 - JavaScript 
- **[优化]** 在 PC 浏览器上，fps 面板和 log 信息面板，增加了 `id`： `egret-fps-panel`，可以通过代码隐藏和显示面板。[教程文档](http://developer.egret.com/cn/github/egret-docs/Engine2D/debug/debug/index.html#4.%E5%8A%A8%E6%80%81%E9%9A%90%E8%97%8F%E5%92%8C%E6%98%BE%E7%A4%BA%E4%BF%A1%E6%81%AF%E9%9D%A2%E6%9D%BF)
- **[优化]** 优化 `vivogame.ts` 里的发布逻辑
- **[修复]** 修复 `eui.Label` 里 `setFontFamily` 方法里的拼写错误

