export const EXCLUDE_FILES = ['game.js', 'game.json', 'project.config.json', 'version.json', 'weapp-adapter.js']
export const DEFAULT_PARENT_DIR = 'release'
export const DEFAULT_WECHAT_GAME_DIR = 'quickgame'
export const DEFAULT_TPL_FILES = ['logo.png']
export const DEFAULT_TPL_FILES_JS = ['main.js']