export const EXCLUDE_FILES = ['openDataContext', 'library', 'egret.wxgame.js', 'game.json', 'platform.js', 'project.config.json', 'weapp-adapter.js']
export const DEFAULT_TPL_FILES = []
export const DEFAULT_TPL_FILES_JS = ['main.js']
export const RENAME_FILES = [
    {"source":"game.js", "target":"main.js"}
]