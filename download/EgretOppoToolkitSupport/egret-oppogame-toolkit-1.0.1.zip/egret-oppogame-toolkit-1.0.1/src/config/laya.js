export const EXCLUDE_FILES = ['game.js', 'game.json', 'project.config.json', 'weapp-adapter.js']
export const DEFAULT_PARENT_DIR = 'release'
export const DEFAULT_WECHAT_GAME_DIR = 'wxgame'
export const DEFAULT_TPL_FILES = []
export const DEFAULT_TPL_FILES_JS = ['main.js']