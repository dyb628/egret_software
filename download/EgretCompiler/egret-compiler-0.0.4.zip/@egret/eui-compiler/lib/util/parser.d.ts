import { AST_Skin } from '../exml-ast';
export declare function generateAST(filecontent: string): AST_Skin;
