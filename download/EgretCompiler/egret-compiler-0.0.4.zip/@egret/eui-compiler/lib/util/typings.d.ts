export declare function getTypings(className: string, propertyKey: string): string | null;
export declare function initTypings(): void;
