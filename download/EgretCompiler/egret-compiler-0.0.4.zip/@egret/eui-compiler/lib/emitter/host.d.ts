export declare class EmitterHost {
    list: any[];
    insertClassDeclaration(x: any): void;
}
