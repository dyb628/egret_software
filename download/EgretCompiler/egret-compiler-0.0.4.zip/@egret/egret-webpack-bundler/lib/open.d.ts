export declare function openUrl(url: string, browserName?: string): void;
export declare function executeCommand(command: string, options?: {}): Promise<void>;
