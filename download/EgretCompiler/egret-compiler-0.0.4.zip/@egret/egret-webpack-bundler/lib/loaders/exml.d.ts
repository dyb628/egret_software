import * as webpack from 'webpack';
declare const exmlLoader: webpack.loader.Loader;
export default exmlLoader;
