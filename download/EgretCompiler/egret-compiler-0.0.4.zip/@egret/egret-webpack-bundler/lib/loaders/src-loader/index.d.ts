import * as webpack from 'webpack';
import SrcLoaderPlugn from './Plugin';
declare const srcLoader: webpack.loader.Loader;
export default srcLoader;
export { SrcLoaderPlugn, };
