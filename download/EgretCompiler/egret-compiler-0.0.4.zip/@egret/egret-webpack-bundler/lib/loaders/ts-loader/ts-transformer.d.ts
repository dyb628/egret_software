import * as ts from 'typescript';
export declare function emitClassName(): (ctx: ts.TransformationContext) => (sf: ts.SourceFile) => ts.SourceFile;
