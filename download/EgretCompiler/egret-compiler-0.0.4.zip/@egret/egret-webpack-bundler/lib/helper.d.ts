export declare const __reflect: (p: any, c: any, t: any) => void;
