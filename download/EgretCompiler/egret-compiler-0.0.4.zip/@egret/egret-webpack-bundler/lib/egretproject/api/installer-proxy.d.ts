import { LauncherAPI } from ".";
export declare function createInstallerLibrary(): LauncherAPI;
