import { LauncherAPI } from ".";
export declare function createLauncherLibrary(): LauncherAPI;
