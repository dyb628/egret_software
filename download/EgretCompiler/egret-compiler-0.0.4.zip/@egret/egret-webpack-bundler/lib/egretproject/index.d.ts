import { Target_Type } from "./data";
export declare function getLibsFileList(target: Target_Type, projectRoot: string, mode: "debug" | "release"): string[];
